<div class="products list">
    <!-- / -->
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>
    <x-partials.products.shop-product-list-tile/>

    <!-- / -->
</div>