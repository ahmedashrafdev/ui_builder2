<!-- PAGE -->
<section class="page-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <x-products.products-list/>
            </div>
            <div class="col-md-4">
                <x-products.products-list/>
            </div>
            <div class="col-md-4">
                <x-products.products-list/>
            </div>
        </div>
    </div>
</section>
<!-- /PAGE -->