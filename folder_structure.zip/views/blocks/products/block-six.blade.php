<section class="page-section light">
    <div class="container">
        <x-carousels.products-two/>
    </div>
</section>