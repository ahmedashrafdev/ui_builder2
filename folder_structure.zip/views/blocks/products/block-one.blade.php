<!-- PAGE -->
<section class="page-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
               <x-partials.products.product-three/>
            </div>
            <div class="col-md-6">
                <x-partials.products.product-three/>
            </div>
        </div>
    </div>
</section>
<!-- /PAGE -->