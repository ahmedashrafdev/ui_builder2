<!-- Products grid -->

<div class="row products grid">
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
    <div class="col-md-4 col-sm-6">
       <x-partials.products.product/>
    </div>
</div>
<!-- /Products grid -->