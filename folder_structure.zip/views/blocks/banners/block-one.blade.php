<section class="page-section no-padding-top">
    <div class="container">
        <div class="row blocks shop-info-banners">
            {{dd($list)}}
            <div class="col-md-4">
                {{-- @include('components.banners.info-banner') --}}
                <x-banners.info-banner/>
            </div>
            <div class="col-md-4">
                {{-- @include('components.banners.info-banner') --}}
                <x-banners.info-banner/>
            </div>
            <div class="col-md-4">
                {{-- @include('components.banners.info-banner') --}}
                <x-banners.info-banner/>
            </div>
        </div>
    </div>
</section>