 <!-- PAGE -->
 <section class="page-section image testimonials">
    <div class="container">
        <h2 class="section-title section-title-lg"><span><span class="thin">What </span> Customers <span class="thin"> Say</span></span></h2>
        <x-carousels.testemonials/>
    </div>
</section>
<!-- /PAGE -->