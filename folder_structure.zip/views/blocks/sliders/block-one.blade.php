<!-- PAGE slider-->
<section class="page-section no-padding slider">
    <div class="container full-width">
        <div class="main-slider">
            <x-carousels.main-slider/>
        </div>

    </div>
</section>
<!-- /PAGE -->