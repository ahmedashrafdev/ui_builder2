<div class="block">
    <div class="media">
        <div class="pull-right"><i class="fa fa-gift"></i></div>
        <div class="media-body">
            <h4 class="media-heading">Buy 1 Get 1</h4>
            Proin dictum elementum velit. Fusce euismod consequat ante.
        </div>
    </div>
</div>