<div class="testimonials-carousel">
    <div class="owl-carousel" id="testimonials">
        <div class="testimonial">
            <div class="testimonial-text">Sed cursus sodales vulputate. Proin viverra est nec sem pretium, varius varius ex fringilla. Donec rutrum, mi sit amet consequat consectetur.</div>
            <div class="testimonial-name">Alice Cincity</div>
        </div>
        <div class="testimonial">
            <div class="testimonial-text">Sed cursus sodales vulputate. Proin viverra est nec sem pretium, varius varius ex fringilla. Donec rutrum, mi sit amet consequat consectetur.</div>
            <div class="testimonial-name">Alice Cincity</div>
        </div>
        <div class="testimonial">
            <div class="testimonial-text">Sed cursus sodales vulputate. Proin viverra est nec sem pretium, varius varius ex fringilla. Donec rutrum, mi sit amet consequat consectetur.</div>
            <div class="testimonial-name">Alice Cincity</div>
        </div>
    </div>
</div>