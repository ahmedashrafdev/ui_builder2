<div class="partners-carousel">
    <div class="owl-carousel" id="partners">
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
        <div><a href="#"><img src="{{asset('storage/assets/img/preview/partners/brand-logo.jpg')}}" alt=""/></a></div>
    </div>
</div>