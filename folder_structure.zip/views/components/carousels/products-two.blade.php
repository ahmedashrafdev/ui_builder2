<div class="featured-products-carousel">
    <div class="owl-carousel" id="featured-products-carousel">
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>
        <x-partials.products.product-two/>

    </div>
</div>