<div class="top-products-carousel">
    <div class="owl-carousel" id="top-products-carousel">
        <x-partials.products.product/>
        <x-partials.products.product/>
        <x-partials.products.product/>
        <x-partials.products.product/>
        <x-partials.products.product/>
        <x-partials.products.product/>
        <x-partials.products.product/>
    </div>
</div>