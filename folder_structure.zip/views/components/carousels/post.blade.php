<div class="owl-carousel img-carousel">
    <div class="item"><a href="assets/img/preview/blog/blog-post-2.jpg" data-gal="prettyPhoto"><img class="img-responsive" src="{{asset('storage/assets/img/preview/blog/blog-post-2.jpg')}}" alt=""/></a></div>
    <div class="item"><a href="assets/img/preview/shop/blog-post-3.html" data-gal="prettyPhoto"><img class="img-responsive" src="{{asset('storage/assets/img/preview/blog/blog-post-3.jpg')}}" alt=""/></a></div>
    <div class="item"><a href="assets/img/preview/shop/blog-post-4.html" data-gal="prettyPhoto"><img class="img-responsive" src="{{asset('storage/assets/img/preview/blog/blog-post-4.jpg')}}" alt=""/></a></div>
    <div class="item"><a href="assets/img/preview/shop/blog-post-1.html" data-gal="prettyPhoto"><img class="img-responsive" src="{{asset('storage/assets/img/preview/blog/blog-post-1.jpg')}}" alt=""/></a></div>
</div>