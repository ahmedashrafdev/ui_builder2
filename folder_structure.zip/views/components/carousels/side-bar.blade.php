<div class="sidebar-products-carousel">
    <div class="owl-carousel" id="sidebar-products-carousel">
        
        <x-partials.products.product-list-tile/>
        <x-partials.products.product-list-tile/>
        <x-partials.products.product-list-tile/>

       
    </div>
</div>