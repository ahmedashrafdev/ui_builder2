<div class="hot-deals-carousel">
    <div class="owl-carousel" id="hot-deals-carousel">
        <x-partials.products.countdown/>
        <x-partials.products.countdown/>
        <x-partials.products.countdown/>
        <x-partials.products.countdown/>
    </div>
</div>