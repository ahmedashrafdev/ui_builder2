 <!-- shop-sorting -->
 <div class="shop-sorting">
    <div class="row">
        <div class="col-sm-8">
            <form class="form-inline" action="#">
                <div class="form-group selectpicker-wrapper">
                    <select
                        class="selectpicker input-price" data-live-search="true" data-width="100%"
                        data-toggle="tooltip" title="Select">
                        <option>Product Name</option>
                        <option>Product Name</option>
                        <option>Product Name</option>
                    </select>
                </div>
                <div class="form-group selectpicker-wrapper">
                    <select
                        class="selectpicker input-price" data-live-search="true" data-width="100%"
                        data-toggle="tooltip" title="Select">
                        <option>Select Manifacturers</option>
                        <option>Select Manifacturers</option>
                        <option>Select Manifacturers</option>
                    </select>
                </div>
            </form>
        </div>
        <div class="col-sm-4 text-right-sm">
            <a class="btn btn-theme btn-theme-transparent btn-theme-sm" href="#"><img src="{{asset('storage/assets/img/icon-list.png')}}" alt=""/></a>
            <a class="btn btn-theme btn-theme-transparent btn-theme-sm" href="#"><img src="{{asset('storage/assets/img/icon-grid.png')}}" alt=""/></a>
        </div>
    </div>
</div>
<!-- /shop-sorting -->