<div class="logo {{isset($hiddenLg) && $hiddenLg ? "hidden-md hidden-lg" : ""}}">
    <a href="index-2.html"><img src="{{asset('storage/assets/img/logo-bella-shop.png')}}" alt="Bella Shop"/></a>
</div>