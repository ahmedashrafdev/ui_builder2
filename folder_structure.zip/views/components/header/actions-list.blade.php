<ul class="list-inline">
    <li class="icon-user"><a href="login.html"><img src="{{asset('storage/assets/img/icon-1.png')}}" alt=""/> <span>Login</span></a></li>
    <li class="icon-form"><a href="login.html"><img src="{{ asset('storage/assets/img/icon-2.png')}}" alt=""/> <span>Not a Member? <span class="colored">Sign Up</span></span></a></li>
    <li><a href="mailto:support@yourdomain.com"><i class="fa fa-envelope"></i> <span>support@yourdomain.com</span></a></li>
</ul>