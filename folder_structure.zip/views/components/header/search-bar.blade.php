<div class="header-search">
    <input class="form-control" type="text" placeholder="What are you looking?"/>
    <button><i class="fa fa-search"></i></button>
</div>