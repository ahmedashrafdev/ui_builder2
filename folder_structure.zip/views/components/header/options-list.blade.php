<ul class="list-inline">
    <li class="hidden-xs"><a href="about.html">About</a></li>
    <li class="hidden-xs"><a href="blog.html">Blog</a></li>                             
    <li class="hidden-xs"><a href="accountinformation.html">My Account</a></li>
    <li class="hidden-xs"><a href="contact.html">Contact</a></li>
    <li class="hidden-xs"><a href="faq.html">FAQ</a></li>
    <li class="hidden-xs"><a href="wishlist.html">My Wishlist</a></li>
    <li class="dropdown currency">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">€ EURO<i class="fa fa-angle-down"></i></a>
        <ul role="menu" class="dropdown-menu">
            <li><a href="#">€ EURO</a></li>
            <li><a href="#">€ EURO</a></li>
            <li><a href="#">€ EURO</a></li>
        </ul>
    </li>
    <li class="dropdown flags">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="{{ asset('storage/assets/img/flag.gif')}}" alt=""/> Eng<i class="fa fa-angle-down"></i></a>
        <ul role="menu" class="dropdown-menu">
            <li><a href="#"><img src="{{ asset('storage/assets/img/flag.gif')}}" alt=""/> Eng</a></li>
            <li><a href="#"><img src="{{ asset('storage/assets/img/flag.gif')}}" alt=""/> Eng</a></li>
            <li><a href="#"><img src="{{ asset('storage/assets/img/flag.gif')}}" alt=""/> Eng</a></li>
        </ul>
    </li>
</ul>