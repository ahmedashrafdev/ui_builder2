<aside class="col-md-3 sidebar" id="sidebar">
    <!-- widget search -->
    <div class="widget">
        <div class="widget-search">
            <input class="form-control" type="text" placeholder="Search">
            <button><i class="fa fa-search"></i></button>
        </div>
    </div>
    <!-- /widget search -->
    <!-- widget shop categories -->
    <x-sidebar.categories/>
    <x-sidebar.colors/>
    <x-sidebar.price/>
    <x-sidebar.tabs/>
    <x-sidebar.tags/>
    <x-sidebar.carousel/>
    <x-sidebar.deals/>
    <!-- /widget shop hot deals -->
</aside>