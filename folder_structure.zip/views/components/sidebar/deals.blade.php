<div class="widget widget-shop-deals">
    <a class="btn btn-theme btn-title-more" href="#">See All</a>
    <h4 class="widget-title"><span>Hot Deals</span></h4>
    <x-carousels.deals/>
</div>