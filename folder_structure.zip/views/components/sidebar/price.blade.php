<div class="widget widget-filter-price">
    <h4 class="widget-title">Price</h4>
    <div class="widget-content">
        <div id="slider-range"></div>
        <input type="text" id="amount" readonly />
        <button class="btn btn-theme">Filter</button>
    </div>
</div>