<div class="widget shop-categories">
    <h4 class="widget-title">Categories</h4>
    <div class="widget-content">
        <ul>
            <li>
                <span class="arrow"><i class="fa fa-angle-down"></i></span>
                <a href="#">Woman</a>
                <ul class="children">
                    <li>
                        <a href="#">Sweaters & Knits
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Jackets & Coats
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Denim
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Pants
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Shorts
                            <span class="count">12</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <span class="arrow"><i class="fa fa-angle-down"></i></span>
                <a href="#">Man</a>
                <ul class="children">
                    <li>
                        <a href="#">Sweaters & Knits
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Jackets & Coats
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Denim
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Pants
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Shorts
                            <span class="count">12</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <span class="arrow"><i class="fa fa-angle-down"></i></span>
                <a href="#">Dress</a>
                <ul class="children">
                    <li>
                        <a href="#">Sweaters & Knits
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Jackets & Coats
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Denim
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Pants
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Shorts
                            <span class="count">12</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <span class="arrow"><i class="fa fa-angle-down"></i></span>
                <a href="#">Top Sellers</a>
                <ul class="children">
                    <li>
                        <a href="#">Sweaters & Knits
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Jackets & Coats
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Denim
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Pants
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Shorts
                            <span class="count">12</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <span class="arrow"><i class="fa fa-angle-up"></i></span>
                <a href="#">Accessories</a>
                <ul class="children active">
                    <li>
                        <a href="#">Sweaters & Knits
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Jackets & Coats
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Denim
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Pants
                            <span class="count">12</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">Shorts
                            <span class="count">12</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li><a href="#">Sale Off</a></li>
        </ul>
    </div>
</div>