<div class="widget widget-tag-cloud">
    <a class="btn btn-theme btn-title-more" href="#">See All</a>
    <h4 class="widget-title"><span>Tags</span></h4>
    <ul>
        <li><a href="#">Fashion</a></li>
        <li><a href="#">Jeans</a></li>
        <li><a href="#">Top Sellers</a></li>
        <li><a href="#">E commerce</a></li>
        <li><a href="#">Hot Deals</a></li>
        <li><a href="#">Supplier</a></li>
        <li><a href="#">Shop</a></li>
        <li><a href="#">Theme</a></li>
        <li><a href="#">Website</a></li>
        <li><a href="#">Isamercan</a></li>
        <li><a href="#">Themeforest</a></li>
    </ul>
</div>