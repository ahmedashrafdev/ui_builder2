<div class="widget widget-colors">
    <h4 class="widget-title">Colors</h4>
    <div class="widget-content">
        <ul>
            <li><a href="#"><span style="background-color: #ffffff"></span></a></li>
            <li><a href="#"><span style="background-color: #161618"></span></a></li>
            <li><a href="#"><span style="background-color: #e74c3c"></span></a></li>
            <li><a href="#"><span style="background-color: #783ce7"></span></a></li>
            <li><a href="#"><span style="background-color: #3498db"></span></a></li>
            <li><a href="#"><span style="background-color: #00a847"></span></a></li>
            <li><a href="#"><span style="background-color: #3ce7d9"></span></a></li>
            <li><a href="#"><span style="background-color: #fa17bc"></span></a></li>
            <li><a href="#"><span style="background-color: #a87e00"></span></a></li>
        </ul>
    </div>
</div>