<div class="widget">
    <a class="btn btn-theme btn-title-more" href="#">See All</a>
    <h4 class="widget-title"><span>Top products</span></h4>

    <x-carousels.side-bar/>
</div>