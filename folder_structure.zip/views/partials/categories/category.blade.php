
<div class="thumbnail no-border no-padding category">
    <div class="media">
        <a class="media-link" href="#">
            <img src="{{asset('storage/assets/img/preview/shop/category-2.jpg')}}" alt="">
            <div class="caption">
                <div class="caption-wrapper div-table">
                    <div class="caption-inner div-cell">
                        <div class="sale"><span>%75 Sale</span></div>
                        <h4 class="caption-title"><span>Shoes</span></h4>
                        <div class="items"><span>7 Items</span></div>
                        <div class="buttons">
                            <span class="btn btn-theme btn-theme-transparent">Shop Now</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>
