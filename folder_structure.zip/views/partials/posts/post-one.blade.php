<div class="recent-post">
    <div class="media">
        <a class="pull-left media-link" href="#">
            <img class="media-object" src="{{asset('storage/assets/img/preview/blog/recent-post-1.jpg')}}" alt="">
            <i class="fa fa-plus"></i>
        </a>
        <div class="media-body">
            <p class="media-category"><a href="#">Shoes</a> / <a href="#">Dress</a></p>
            <h4 class="media-heading"><a href="#">Standard Post Comment Header Here</a></h4>
            Fusce gravida interdum eros a mollis. Sed non lorem varius, volutpat nisl in, laoreet ante.
            <div class="media-meta">
                6th June 2014
                <span class="divider">/</span><a href="#"><i class="fa fa-comment"></i>27</a>
                <span class="divider">/</span><a href="#"><i class="fa fa-heart"></i>18</a>
            </div>
        </div>
    </div>
</div>