<div class="thumbnail thumbnail-hot-deal no-border no-padding">
    <div class="media">
        <a class="media-link" href="#">
            <img src="{{asset('storage/assets/img/preview/shop/product-5.jpg')}}" alt=""/>
            <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
            <div class="countdown-wrapper">
                <div id="dealCountdown1" class="defaultCountdown clearfix"></div>
            </div>
        </a>
    </div>
    <div class="caption text-center">
        <h4 class="caption-title">Standard Hot Deal Product</h4>
        <div class="rating">
            <span class="star"></span><!--
            --><span class="star active"></span><!--
            --><span class="star active"></span><!--
            --><span class="star active"></span><!--
            --><span class="star active"></span>
        </div>
        <span class="reviews">16 reviews</span>
        <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
        <div class="caption-text">Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan.</div>
    </div>
</div>