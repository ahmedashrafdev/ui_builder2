<div class="media">
    <a class="pull-left media-link" href="#">
        <img class="media-object" src="{{asset('storage/assets/img/preview/shop/top-sellers-1.jpg')}}" alt="">
        <i class="fa fa-plus"></i>
    </a>
    <div class="media-body">
        <h4 class="media-heading"><a href="#">Standard Product Header</a></h4>
        <div class="rating">
            <span class="star"></span><!--
            --><span class="star active"></span><!--
            --><span class="star active"></span><!--
            --><span class="star active"></span><!--
            --><span class="star active"></span>
        </div>
        <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
    </div>
</div>